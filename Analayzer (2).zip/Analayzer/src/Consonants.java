
public  class Consonants extends Phoneme {

	
	String articulationPlace;
	int voicing;
	//String articulationStyle;
	int sonorntRank;
	int distortionType;
	
	public Consonants (String letter) {
		super(letter);
	}
	

	

	
}