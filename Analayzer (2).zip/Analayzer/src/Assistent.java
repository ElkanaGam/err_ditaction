import java.util.ArrayList;
import java.util.List;

import org.omg.CORBA.Current;

public class Assistent {
	/*get a String word, devied it to its syllable and return List contains all the syllable*/
	static List <Syllable> WordToSyllable (String word){
		List <Syllable> retList= new ArrayList<Syllable>();
		
		return retList;
		
	}
	/*return true iff a char c isnt in the list {a,e,i,o,u} */
	static boolean isNotVowel(char c) {
		if (c=='a'||c=='e'||c=='o'||c=='u'||c=='i') {
			return false;
		}
		return true;
	}
	/*return a list which each element is in type BoundList and contain pair of correspond
	 * syllable in src and prod. if syllable in src has no correspond syllable in prod then omission has occured,  
	 * and it will be match to null. for example:
	 * matchlist("banana", "nana")->[(ba,null),(na,na),(na,na)] */
	static List <BoundList<Syllable>> MatchSyllable (Word src, Word prod){
		 List <BoundList<Syllable>> retList=new ArrayList<BoundList<Syllable>>();
		 int srcl=src.SyllNum;
		 int prodl=prod.SyllNum;
		 if (srcl==prodl) {		//the number of Syllable is equal. there is no omission
			 for (int k =0; k<srcl;k++) {
				 BoundList<Syllable> boundList=new BoundList<>();
				 boundList.add(src.SyllList.get(k)); //create the match between every Syll and add it to the List
				 boundList.add(prod.SyllList.get(k));
				 retList.add(boundList);
			 }
			 return retList;
		 }else {			 // i>j, omission has occurred
			 int i=0;
			 int j=0;
			 while (j<prodl) { 
			 	if (src.SyllList.get(i).getRhyme().equals(prod.SyllList.get(j).getRhyme())) {
					 //need to check all the syll!!!
			 		 //if ryhme is equal- chec ths consonants, if not still check consonant
			 		 //need to be very precisely and careful
			 		
			 		 BoundList<Syllable> boundList=new BoundList<>();
					 boundList.add(src.SyllList.get(i)); 
					 boundList.add(prod.SyllList.get(j));
					 retList.add(boundList);
					 i++;
					 j++;
				 }else {
					 // add to list(src.get(i), null)
					 i++;
				 }// from j to end of src add null
			 }
			 
		 }
	}

	static int FindDiff (Syllable current, Syllable candidate) {
		int onsetDiff=ClusretrDiff(current.getOnset(), candidate.getOnset());
		int ryhmeDiff=RyhmeDiff(current.getRhyme(), candidate.getRhyme());
		int codaDiff=ClusretrDiff(current.getCoda(), candidate.getCoda());
		return onsetDiff+ryhmeDiff+codaDiff;

		
	}
	static int ClusretrDiff(List <Consonants> cur, List <Consonants> can) {
		int diff=0;
		int curL=cur.size();
		int canL=can.size();
		if (curL>canL){				//one or more Cons was omitted
			diff++;
			if (canL>0) {
				int conDiff=200;        //just a big enough number
				for (int i=0; i<canL; i++) {
					Consonants a=cur.get(i);
					Consonants b=can.get(i);
					if(conDiff>ConDiff(a,b)) {
						conDiff=ConDiff(a,b);
						diff=diff+conDiff;
					}
				}
			}return diff;
		}
		else {						//nothing was omitted		
			for (int i=0; i<curL; i++) {
				diff=diff+(ConDiff(cur.get(i), can.get(i)));
				return diff;
			}
		}
		return diff;	
	}
	
	private static int ConDiff(Consonants a, Consonants b) {
		int diff=0;
		if (!a.articulationPlace.equals(b.articulationPlace)) {
			diff++;
		}
		if (a.voicing!=b.voicing) {
			diff++;
		}
		if (!a.getClass().equals(b.getClass())) {
			diff++;
		}
		return diff;
	}
	private static int RyhmeDiff(Phoneme a, Phoneme b) {
		int diff=0;
		if (!a.Name.equals(b.Name)){ //vowel subtitution
			diff++;			
		}
		return diff;
	}
}
