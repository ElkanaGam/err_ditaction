
public class Deafricative extends Consonants {

	public Deafricative(String letter) {
		super(letter);
		this.articulationPlace="dental";
		this.voicing=0;
		this.sonorntRank=2;
		
		
	}
}
