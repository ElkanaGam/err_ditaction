
public class Vowel extends Phoneme{

	public Vowel (String letter) {
		super (letter);
	}
}
