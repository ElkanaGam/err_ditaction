
public class Phoneme {
	
	String Name;
	
	public Phoneme(String letter) {
		this.Name=letter;
	}

}
